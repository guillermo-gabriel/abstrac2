package alimentacion;

public class Planta extends SerVivo  {

	
	
	public void alimentarse() {
		System.out.println("la planta se alimenta a traves de la fotosintesis");
	}
	
	
}
