package alimentacion;

public class AnimalCarnivoro extends Animal {
 
	
	public void alimentarse() {
		System.out.println("El animal carnivoro se alimenta de carne");
	}
}
