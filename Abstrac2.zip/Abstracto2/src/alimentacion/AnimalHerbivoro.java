package alimentacion;

public class AnimalHerbivoro extends Animal {

	public void alimentarse() {
		
		System.out.println("El animal Herbivoro se alimenta de hierba ");
	}
	
}
