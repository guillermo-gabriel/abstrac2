package alimentacion;

public abstract class Animal extends SerVivo {
}
