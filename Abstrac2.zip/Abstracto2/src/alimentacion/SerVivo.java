package alimentacion;

public abstract class SerVivo {
	
	public abstract void alimentarse();	
}
